import nltk
nltk.download('all')
